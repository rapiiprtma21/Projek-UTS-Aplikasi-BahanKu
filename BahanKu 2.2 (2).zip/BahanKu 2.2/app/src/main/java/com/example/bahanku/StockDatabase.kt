package com.example.bahanku

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val quantity: Int,
    val unit: String,
    val minimum: Int
)

@Dao
interface StockDao {
    @Query("SELECT * FROM stock_items ORDER BY name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<StockItem>>

    @Insert
    suspend fun insert(item: StockItem)

    @Update
    suspend fun update(item: StockItem)

    @Query("SELECT COUNT(*) FROM stock_items")
    suspend fun countItems(): Int

    @Query("SELECT COUNT(*) FROM stock_items WHERE LOWER(name) = LOWER(:name)")
    suspend fun countByName(name: String): Int
}

@Database(entities = [StockItem::class], version = 1, exportSchema = false)
abstract class StockDatabase : RoomDatabase() {
    abstract fun stockDao(): StockDao

    companion object {
        @Volatile private var INSTANCE: StockDatabase? = null

        fun getInstance(context: Context): StockDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StockDatabase::class.java,
                    "bahanku_database"
                ).build().also { INSTANCE = it }
            }
    }
}
