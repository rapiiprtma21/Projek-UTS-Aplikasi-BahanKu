package com.example.bahanku

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

private val Green = Color(0xFF167A52)
private val Dark = Color(0xFF17211D)
private val Muted = Color(0xFF75817B)
private val Canvas = Color(0xFFF5F7F5)
private val PaleGreen = Color(0xFFE4F4EB)
private val PaleOrange = Color(0xFFFFF0D9)
private val Orange = Color(0xFFB86A12)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = StockDatabase.getInstance(applicationContext).stockDao()
        setContent { BahanKuApp(dao) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BahanKuApp(dao: StockDao) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("bahanku_session", android.content.Context.MODE_PRIVATE) }
    var loggedIn by remember { mutableStateOf(prefs.getBoolean("logged_in", false)) }
    if (!loggedIn) {
        LoginScreen(
            onLogin = { username ->
                prefs.edit().putBoolean("logged_in", true).putString("username", username).apply()
                loggedIn = true
            }
        )
        return
    }

    val stock by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(0) }
    var selectedItem by remember { mutableStateOf<StockItem?>(null) }
    var action by remember { mutableStateOf("Masuk") }

    LaunchedEffect(Unit) {
        if (dao.countItems() == 0) {
            listOf(
                StockItem(name="Beras", category="Bahan pokok", quantity=10, unit="kg", minimum=5),
                StockItem(name="Ayam", category="Bahan segar", quantity=5, unit="kg", minimum=3),
                StockItem(name="Cabai merah", category="Sayuran", quantity=2, unit="kg", minimum=4),
                StockItem(name="Minyak goreng", category="Cairan", quantity=8, unit="liter", minimum=3),
                StockItem(name="Tepung terigu", category="Bahan kering", quantity=20, unit="kg", minimum=8),
                StockItem(name="Cokelat bubuk", category="Bahan kering", quantity=1, unit="kg", minimum=2),
                StockItem(name="Susu cair", category="Bahan cair", quantity=6, unit="liter", minimum=3)
            ).forEach { dao.insert(it) }
        } else {
            // Tambahkan dua bahan contoh ke database lama jika belum ada.
            if (dao.countByName("Cokelat bubuk") == 0) {
                dao.insert(StockItem(name="Cokelat bubuk", category="Bahan kering", quantity=1, unit="kg", minimum=2))
            }
            if (dao.countByName("Susu cair") == 0) {
                dao.insert(StockItem(name="Susu cair", category="Bahan cair", quantity=6, unit="liter", minimum=3))
            }
        }
    }

    val shown = stock.filter { it.name.contains(search, true) }
    val low = stock.count { it.quantity <= it.minimum }
    val total = stock.sumOf { it.quantity }

    if (menuOpen) {
        MenuDashboardScreen(
            username = prefs.getString("username", "Admin") ?: "Admin",
            onBack = { menuOpen = false },
            onSummary = { selected = 0; menuOpen = false },
            onInventory = { selected = 1; menuOpen = false },
            onLogout = {
                prefs.edit().putBoolean("logged_in", false).apply()
                loggedIn = false
                menuOpen = false
            }
        )
        return
    }

    MaterialTheme(colorScheme = lightColorScheme(primary=Green, onPrimary=Color.White, background=Canvas, surface=Color.White, onSurface=Dark)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor=Color.White) {
                    NavigationBarItem(selected==0, { selected=0 }, icon={ Icon(Icons.Default.Inventory2, null) }, label={ Text("Ringkasan") })
                    NavigationBarItem(selected==1, { selected=1 }, icon={ Icon(Icons.Default.Tune, null) }, label={ Text("Persediaan") })
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick={ showAdd=true }, containerColor=Green, contentColor=Color.White, shape=RoundedCornerShape(18.dp)) {
                    Icon(Icons.Default.Add, contentDescription="Tambah bahan")
                }
            }
        ) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding=PaddingValues(horizontal=16.dp, vertical=14.dp),
                verticalArrangement=Arrangement.spacedBy(13.dp)
            ) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(154.dp).clip(RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Image(
                            painter = painterResource(R.drawable.header_bahan),
                            contentDescription = "Foto bahan baku", contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(Modifier.fillMaxSize().background(Color(0x7510563B)))
                        Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Halo, selamat datang 👋", color=Color.White.copy(alpha=.85f), fontSize=13.sp)
                                Text("BahanKu", fontSize=28.sp, fontWeight=FontWeight.Bold, color=Color.White)
                                Text("Kelola stok, jadi lebih mudah.", color=Color.White, fontSize=14.sp)
                            }
                            Surface(
                                shape=CircleShape, color=Color.White,
                                modifier=Modifier.size(48.dp),
                                onClick={ menuOpen = true }
                            ) {
                                Box(contentAlignment=Alignment.Center) {
                                    Icon(Icons.Default.Menu, contentDescription="Buka dashboard menu", tint=Dark)
                                }
                            }
                        }
                    }
                }
                item {
                    Surface(shape=RoundedCornerShape(24.dp), color=Green, modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("TOTAL PERSEDIAAN", color=Color.White.copy(alpha=.75f), fontSize=11.sp, fontWeight=FontWeight.SemiBold, letterSpacing=1.2.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment=Alignment.Bottom) {
                                Text("$total", color=Color.White, fontSize=38.sp, fontWeight=FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                                Text("unit tercatat", color=Color.White.copy(alpha=.8f), fontSize=13.sp, modifier=Modifier.padding(bottom=7.dp))
                            }
                            Spacer(Modifier.height(15.dp))
                            Text("${stock.size} jenis bahan baku", color=Color.White, fontSize=13.sp)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        SummaryCard(Modifier.weight(1f), "Stok menipis", "$low bahan", "Perlu dicek", PaleOrange, Orange)
                        SummaryCard(Modifier.weight(1f), "Jenis bahan", "${stock.size} item", "Dalam inventaris", PaleGreen, Green)
                    }
                }
                item {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(if(selected==0) "Bahan baku" else "Semua persediaan", fontSize=20.sp, fontWeight=FontWeight.Bold, color=Dark, modifier=Modifier.weight(1f))
                        Text("${shown.size} item", fontSize=12.sp, color=Muted)
                    }
                    OutlinedTextField(
                        value=search, onValueChange={search=it}, modifier=Modifier.fillMaxWidth(),
                        placeholder={ Text("Cari nama bahan...", color=Muted) },
                        leadingIcon={ Icon(Icons.Default.Search, null, tint=Muted) },
                        singleLine=true, shape=RoundedCornerShape(16.dp),
                        colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White, focusedContainerColor=Color.White, unfocusedBorderColor=Color(0xFFE6EBE7), focusedBorderColor=Green)
                    )
                }
                if (shown.isEmpty()) item { Text("Bahan tidak ditemukan. Tekan + untuk menambah bahan baru.", color=Muted) }
                else items(shown, key={it.id}) { item ->
                    StockRow(item, { selectedItem=item; action="Masuk" }, { selectedItem=item; action="Keluar" })
                }
                item { Text("BahanKu 2.2 • Powered By Raffi", color=Muted, fontSize=11.sp, modifier=Modifier.fillMaxWidth(), textAlign=TextAlign.Center) }
            }
        }

        if(showAdd) AddDialog(
            onClose={showAdd=false},
            onSave={ name, category, qty, unit, min ->
                scope.launch { dao.insert(StockItem(name=name, category=category, quantity=qty, unit=unit, minimum=min)) }
                showAdd=false
            }
        )
        selectedItem?.let { item ->
            QuantityDialog(item, action, {selectedItem=null}) { amount ->
                scope.launch {
                    val newQty = if(action=="Masuk") item.quantity+amount else (item.quantity-amount).coerceAtLeast(0)
                    dao.update(item.copy(quantity=newQty))
                }
                selectedItem=null
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuDashboardScreen(
    username: String,
    onBack: () -> Unit,
    onSummary: () -> Unit,
    onInventory: () -> Unit,
    onLogout: () -> Unit
) {
    var infoTitle by remember { mutableStateOf<String?>(null) }
    var infoText by remember { mutableStateOf("") }

    MaterialTheme(colorScheme=lightColorScheme(primary=Green, onPrimary=Color.White, background=Canvas, surface=Color.White, onSurface=Dark)) {
        Scaffold(
            containerColor=Canvas,
            topBar={
                TopAppBar(
                    title={ Text("Dashboard Menu", fontWeight=FontWeight.Bold) },
                    navigationIcon={
                        IconButton(onClick=onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription="Kembali")
                        }
                    },
                    colors=TopAppBarDefaults.topAppBarColors(containerColor=Canvas)
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal=18.dp, vertical=12.dp),
                verticalArrangement=Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    shape=RoundedCornerShape(24.dp),
                    color=Green,
                    modifier=Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(20.dp), verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=CircleShape, color=Color.White.copy(alpha=.18f), modifier=Modifier.size(54.dp)) {
                            Box(contentAlignment=Alignment.Center) {
                                Icon(Icons.Default.AccountCircle, null, tint=Color.White, modifier=Modifier.size(34.dp))
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Halo, $username 👋", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                            Text("Selamat datang di BahanKu", color=Color.White.copy(alpha=.85f), fontSize=13.sp)
                        }
                    }
                }
                Text("Menu utama", fontSize=18.sp, fontWeight=FontWeight.Bold, color=Dark)
                MenuDashboardItem(
                    icon={ Icon(Icons.Default.Dashboard, null, tint=Green) },
                    title="Ringkasan",
                    subtitle="Lihat total dan kondisi persediaan",
                    onClick=onSummary
                )
                MenuDashboardItem(
                    icon={ Icon(Icons.Default.Inventory2, null, tint=Green) },
                    title="Semua Persediaan",
                    subtitle="Kelola bahan baku dan jumlah stok",
                    onClick=onInventory
                )
                MenuDashboardItem(
                    icon={ Icon(Icons.Default.Notifications, null, tint=Green) },
                    title="Notifikasi",
                    subtitle="Informasi dan pengingat stok",
                    onClick={
                        infoTitle="Notifikasi"
                        infoText="Fitur notifikasi stok akan membantu mengingatkan bahan yang sudah mencapai batas minimum."
                    }
                )
                MenuDashboardItem(
                    icon={ Icon(Icons.Default.Person, null, tint=Green) },
                    title="Profil Admin",
                    subtitle="Lihat akun yang sedang digunakan",
                    onClick={
                        infoTitle="Profil Admin"
                        infoText="Nama pengguna: $username\nJenis akun: Admin lokal"
                    }
                )
                MenuDashboardItem(
                    icon={ Icon(Icons.Default.Settings, null, tint=Green) },
                    title="Pengaturan",
                    subtitle="Pengaturan aplikasi BahanKu",
                    onClick={
                        infoTitle="Pengaturan"
                        infoText="Pengaturan aplikasi akan tersedia pada pengembangan berikutnya."
                    }
                )
                Spacer(Modifier.weight(1f))
                OutlinedButton(
                    onClick=onLogout,
                    modifier=Modifier.fillMaxWidth().height(52.dp),
                    shape=RoundedCornerShape(15.dp),
                    colors=ButtonDefaults.outlinedButtonColors(contentColor=Color(0xFFB3261E))
                ) {
                    Icon(Icons.Default.Logout, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Keluar dari akun")
                }
            }
        }
    }

    infoTitle?.let { title ->
        AlertDialog(
            onDismissRequest={ infoTitle=null },
            title={ Text(title, fontWeight=FontWeight.Bold) },
            text={ Text(infoText) },
            confirmButton={ TextButton(onClick={infoTitle=null}) { Text("Tutup") } }
        )
    }
}

@Composable
fun MenuDashboardItem(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        onClick=onClick,
        modifier=Modifier.fillMaxWidth(),
        shape=RoundedCornerShape(18.dp),
        color=Color.White,
        shadowElevation=1.dp
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment=Alignment.CenterVertically
        ) {
            Surface(shape=RoundedCornerShape(13.dp), color=PaleGreen, modifier=Modifier.size(46.dp)) {
                Box(contentAlignment=Alignment.Center) { icon() }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight=FontWeight.SemiBold, color=Dark, fontSize=15.sp)
                Text(subtitle, color=Muted, fontSize=12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint=Muted)
        }
    }
}

@Composable
fun LoginScreen(onLogin: (String) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    val valid = username.isNotBlank() && password.isNotBlank()

    MaterialTheme(colorScheme=lightColorScheme(primary=Green, onPrimary=Color.White, background=Canvas, surface=Color.White, onSurface=Dark)) {
        Box(
            modifier=Modifier.fillMaxSize().background(Canvas).padding(24.dp),
            contentAlignment=Alignment.Center
        ) {
            Surface(
                modifier=Modifier.fillMaxWidth(),
                shape=RoundedCornerShape(28.dp),
                color=Color.White,
                shadowElevation=5.dp
            ) {
                Column(
                    modifier=Modifier.padding(24.dp),
                    verticalArrangement=Arrangement.spacedBy(16.dp),
                    horizontalAlignment=Alignment.CenterHorizontally
                ) {
                    Surface(shape=RoundedCornerShape(20.dp), color=PaleGreen, modifier=Modifier.size(68.dp)) {
                        Box(contentAlignment=Alignment.Center) {
                            Icon(Icons.Default.Inventory2, null, tint=Green, modifier=Modifier.size(34.dp))
                        }
                    }
                    Text("Selamat datang", fontSize=25.sp, fontWeight=FontWeight.Bold, color=Dark)
                    Text("Masuk untuk mengelola persediaan BahanKu", color=Muted, textAlign=TextAlign.Center, fontSize=13.sp)
                    OutlinedTextField(
                        value=username, onValueChange={username=it},
                        modifier=Modifier.fillMaxWidth(), singleLine=true,
                        label={Text("Nama pengguna")},
                        leadingIcon={Icon(Icons.Default.Person, null)},
                        shape=RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value=password, onValueChange={password=it},
                        modifier=Modifier.fillMaxWidth(), singleLine=true,
                        label={Text("Kata sandi")},
                        leadingIcon={Icon(Icons.Default.Lock, null)},
                        visualTransformation=if(showPassword) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon={
                            IconButton(onClick={showPassword=!showPassword}) {
                                Icon(if(showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription="Tampilkan kata sandi")
                            }
                        },
                        shape=RoundedCornerShape(14.dp)
                    )
                    Button(
                        onClick={onLogin(username.trim())},
                        enabled=valid,
                        modifier=Modifier.fillMaxWidth().height(52.dp),
                        shape=RoundedCornerShape(14.dp)
                    ) { Text("Masuk", fontWeight=FontWeight.Bold) }
                    Text(
                        "Mode lokal: isi nama pengguna dan kata sandi apa saja untuk masuk.",
                        color=Muted, fontSize=11.sp, textAlign=TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SummaryCard(modifier: Modifier, label: String, value: String, note: String, bg: Color, accent: Color) {
    Surface(modifier, shape=RoundedCornerShape(20.dp), color=bg) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color=accent, fontSize=12.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, color=Dark, fontSize=20.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(note, color=accent, fontSize=11.sp)
        }
    }
}

@Composable
fun StockRow(item: StockItem, onIn: () -> Unit, onOut: () -> Unit) {
    val isLow = item.quantity <= item.minimum
    val photo = ingredientPhoto(item.name)
    Surface(color=Color.White, shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Image(
                    painter = painterResource(photo),
                    contentDescription = "Foto ${item.name}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(92.dp).background(PaleGreen, RoundedCornerShape(15.dp))
                )
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, fontWeight=FontWeight.Bold, fontSize=16.sp, color=Dark, maxLines=1, overflow=TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(item.category, color=Muted, fontSize=12.sp)
                    Text("${item.quantity} ${item.unit}", color=Dark, fontSize=17.sp, fontWeight=FontWeight.Bold)
                    Surface(color=if(isLow) PaleOrange else PaleGreen, shape=RoundedCornerShape(30.dp)) {
                        Text(if(isLow) "● Stok menipis" else "● Stok aman", color=if(isLow) Orange else Green, fontSize=11.sp, modifier=Modifier.padding(horizontal=9.dp, vertical=4.dp))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick=onIn, modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.ArrowDownward, null, modifier=Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Stok masuk", fontSize=12.sp)
                }
                OutlinedButton(onClick=onOut, modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.ArrowUpward, null, modifier=Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Stok keluar", fontSize=12.sp)
                }
            }
        }
    }
}

@Composable
private fun ingredientPhoto(name: String): Int {
    val n = name.lowercase()
    return when {
        "beras" in n || "rice" in n -> R.drawable.bahan_beras
        "ayam" in n || "daging" in n -> R.drawable.bahan_ayam
        "cabai" in n || "cabe" in n || "tomat" in n -> R.drawable.bahan_cabai
        "minyak" in n -> R.drawable.bahan_minyak
        "tepung" in n || "terigu" in n -> R.drawable.bahan_tepung
        "coklat" in n || "cokelat" in n || "cocoa" in n -> R.drawable.bahan_coklat_bubuk
        "susu" in n || "milk" in n -> R.drawable.bahan_susu_cair
        "Gula Pasir" in n || "gula" in n -> R.drawable.bahan_gula1


        else -> R.drawable.bahan_umum
    }
}

@Composable
fun AddDialog(onClose: () -> Unit, onSave: (String,String,Int,String,Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Bahan kering") }
    var qty by remember { mutableStateOf("0") }
    var unit by remember { mutableStateOf("kg") }
    var min by remember { mutableStateOf("5") }
    val valid = name.isNotBlank() && (qty.toIntOrNull() ?: -1)>=0 && (min.toIntOrNull() ?: -1)>=0
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("Tambah bahan baku", fontWeight=FontWeight.Bold)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name,{name=it},label={Text("Nama bahan")},singleLine=true)
                OutlinedTextField(category,{category=it},label={Text("Kategori")},singleLine=true)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(qty,{qty=it.filter(Char::isDigit)},label={Text("Jumlah")},modifier=Modifier.weight(1f),singleLine=true)
                    OutlinedTextField(unit,{unit=it},label={Text("Satuan")},modifier=Modifier.weight(1f),singleLine=true)
                }
                OutlinedTextField(min,{min=it.filter(Char::isDigit)},label={Text("Batas stok menipis")},singleLine=true)
            }
        },
        confirmButton={TextButton(onClick={if(valid) onSave(name.trim(),category.trim().ifBlank{"Umum"},qty.toInt(),unit.trim().ifBlank{"unit"},min.toInt())},enabled=valid){Text("Simpan")}},
        dismissButton={TextButton(onClick=onClose){Text("Batal")}}
    )
}

@Composable
fun QuantityDialog(item: StockItem, type: String, onClose: () -> Unit, onSave: (Int) -> Unit) {
    var amount by remember { mutableStateOf("1") }
    val number = amount.toIntOrNull() ?: 0
    val enough = type=="Masuk" || number<=item.quantity
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("Stok $type", fontWeight=FontWeight.Bold)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                Text("${item.name} • stok saat ini ${item.quantity} ${item.unit}", color=Muted)
                OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah ${item.unit}")},singleLine=true)
                if(!enough) Text("Jumlah melebihi stok yang tersedia.",color=Color(0xFFB3261E),fontSize=12.sp)
            }
        },
        confirmButton={TextButton(onClick={if(number>0 && enough) onSave(number)},enabled=number>0 && enough){Text("Simpan")}},
        dismissButton={TextButton(onClick=onClose){Text("Batal")}}
    )
}
